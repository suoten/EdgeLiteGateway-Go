function o(r,n=2){if(r==null||r==="")return"-";const e=typeof r=="string"?Number(r):r;return typeof e!="number"||isNaN(e)?"-":e.toFixed(n).replace(/\.?0+$/,"")||"0"}export{o as f};
